// scripts/actions/utils/reviewManager.js
/**
 * !!!! НИЧЕГО НЕ ТРОГАТЬ !!!!
 * Модуль reviewManager.
 * Функция run выводит в консоль сообщение о работе reviewManager.
 */

function run() {
  console.log('я reviewManager работаю');
}

module.exports = { run };
